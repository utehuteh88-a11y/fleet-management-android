# CV Tetap Jaya — Project Android APK (WebView)

Project Android Studio / Gradle ini dibuat otomatis untuk membungkus Web App:
`https://script.google.com/macros/s/AKfycbwyGX1ZK8vC1g6m_IyYx0PGDyafqLfKskYqAP0YRMuNpF7pyvktWXL6y65QqZgv9tbT/exec`

## Cara 1: Build File .APK Otomatis di Cloud (Tanpa Install Android Studio)
1. Buat repository baru di GitHub (https://github.com/new) — pilih Private atau Public.
2. Upload seluruh isi folder project dari ZIP ini ke repository tersebut (pastikan folder `.github/workflows/build-apk.yml` ikut terupload).
3. Buka tab **Actions** di GitHub repository Anda -> klik **Build Android APK** -> klik **Run workflow**.
4. Tunggu ~2 menit hingga selesai, lalu unduh file **CV-Tetap-Jaya-Fleet-APK** (berisi `app-debug.apk`) di bagian **Artifacts**.
5. Kirim `app-debug.apk` ke HP Android lalu pasang (izinkan "Sumber tidak dikenal / Unknown sources" jika diminta).

## Cara 2: Build Lokal via Android Studio
1. Ekstrak file ZIP ini.
2. Buka folder di **Android Studio** (File -> Open).
3. Tunggu proses Gradle Sync selesai.
4. Klik menu **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
5. File `.apk` siap dipakai di HP Android supir, kernet, dan admin.
